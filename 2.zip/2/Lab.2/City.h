#ifndef CITY_H_INCLUDED
#define CITY_H_INCLUDED
#include <iostream>
using namespace std;

class City
{
private:
    string name;
    int countResidents;
    string country;
public:
	City();
	City(const string name, const int countResidents, const string country);
	City(City &c);
	~City();

	const string getname();
	void setname(const string name);
	const int getcountResidents();
	void setcountResidents(const int countResidents);
	const string getcountry();
	void setcountry(const string country);

	const void print();

	City& operator =(const City& ct);
};

#endif // CITY_H_INCLUDED
