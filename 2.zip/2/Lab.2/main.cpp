#include <iostream>
#include "City.h"
#include "City.cpp"

int main()
{
    City None;
    None.print();

    City b("Moscow city", 282, "Moscow");
    b.print();

    City c = b;
    c.setcountResidents(141);
    c.print();

    City d;
    d = c;
    d.setname("Saratov");
    d.setcountry("Russia");
    d.print();

    return 0;
}
