#include "City.h"

City::City()
{
	this->name = "None";
	this->countResidents = 0;
	this->country = "None";
}
City::City(const string name, const int countResidents, const string country)
{
	this->name = name;
	this->countResidents = countResidents;
	this->country = country;
}
City::City(City &c)
{
    this->name = c.name;
    this->countResidents = c.countResidents;
    this->country = c.country;
}
City::~City()
{
    std::cout << name << ", " << country << " was deleted.\n" << std::endl;
}

    const string City::getname() { return name; }
	void City::setname(const string name) { this->name = name; }
	const int City::getcountResidents() { return countResidents; }
	void City::setcountResidents(const int countResidents) { this->countResidents = countResidents; }
	const string City::getcountry() { return country; }
	void City::setcountry(const string country) { this->country = country; }


 const void City::print()
{
    cout << "Name: " << name << "\nPopulation: " << countResidents << "\nCountry: " << country << endl << endl;
}

City& City::operator=(const City& ct)
{
    if(this == &ct)
        return *this;
    City::name = ct.name;
    City::countResidents = ct.countResidents;
    City::country = ct.country;
    return *this;
}
