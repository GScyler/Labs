#pragma once
#include "Node.h"
template<class T>
class BSTree
{
public:
    Node<T>* getFreeNode(T value, Node<T>* parent);
    void insert(Node<T>** head, T value);
    Node<T>* getNode(Node<T>* root, T value);
    void isContains(Node<T>* root, T value);
    Node<T>* getMaxNode(Node<T>* root);
    void delNode(Node<T>* target, T volue);
    void del(Node<T>* root, T value);
    void printBST(Node<T>* root, const char* dir, int level);
    void print(Node<T>* root);
    void isEmpty(Node<T>* root);
    void clear(Node<T>** root);
};
template<class T>
Node<T>* BSTree<T>::getFreeNode(T value, Node<T>* parent)
{
    Node<T>* tmp = new Node<T>;
    tmp->setdata(value);
    tmp->setparent(parent);
    return tmp;
}
template<class T>
void BSTree<T>::insert(Node<T>** head, T value)
{
    Node<T>* tmp = NULL;
    Node<T>* ins = NULL;
    if (*head == NULL)
    {
        *head = getFreeNode(value, NULL);
        cout << "Element " << value << " was added\n" << endl;
        return;
    }

    tmp = *head;
    while (tmp)
    {
        if (value > tmp->getdata())
        {
            if (tmp->getright())
            {
                tmp = tmp->getright();
                continue;
            }
            else
            {
                tmp->setright(getFreeNode(value, tmp));
                cout << "Element " << value << " was added\n" << endl;
                return;
            }
        }
        else if (value < tmp->getdata())
        {
            if (tmp->getleft())
            {
                tmp = tmp->getleft();
                continue;
            }
            else
            {
                tmp->setleft(getFreeNode(value, tmp));
                cout << "Element " << value << " was added\n" << endl;
                return;
            }
        }
    }
}
template<class T>
Node<T>* BSTree<T>::getNode(Node<T>* root, T value)
{
    while (root)
    {
        if (root->getdata() > value)
        {
            root = root->getleft();
            continue;
        }
        else if (root->getdata() < value)
        {
            root = root->getright();
            continue;
        }
        else
        {
            return root;
        }
    }
    return NULL;
}
template<class T>
void BSTree<T>::isContains(Node<T>* root, T value)
{
    if (getNode(root, value))
    {
        cout << "Element " << value << " was found\n" << endl;
        return;
    }
    cout << "Element " << value << " wasn't found\n" << endl;
}
template<class T>
Node<T>* BSTree<T>::getMaxNode(Node<T>* root)
{
    while (root->getright())
    {
        root = root->getright();
    }
    return root;
}
template<class T>
void BSTree<T>::delNode(Node<T>* target, T value)
{
    if (target->getleft() && target->getright())
    {
        Node<T>* localMax = getMaxNode(target->getleft());
        target->setdata(localMax->getdata());
        delNode(localMax, value);
        return;
    }
    else if (target->getleft())
    {
        if (target == target->getparent()->getleft())
        {
            target->getparent()->setleft(target->getleft());
        }
        else
        {
            target->getparent()->setright(target->getleft());
        }
    }
    else if (target->getright())
    {
        if (target == target->getparent()->getright())
        {
            target->getparent()->setright(target->getright());
        }
        else
        {
            target->getparent()->setleft(target->getright());
        }
    }
    else {
        if (target == target->getparent()->getleft())
        {
            target->getparent()->setleft(NULL);
        }
        else
        {
            target->getparent()->setright(NULL);
        }
    }
}
template<class T>
void BSTree<T>::del(Node<T>* root, T value)
{
    Node<T>* target = getNode(root, value);
    delNode(target, value);
    cout << "Element " << value << " was deleted\n" << endl;
}
template<class T>
void BSTree<T>::printBST(Node<T>* root, const char* dir, int level)
{
    if (root)
    {
        cout << "lvl " << level << " " << dir << " " << root->getdata() << endl;
        printBST(root->getleft(), "left", level + 1);
        printBST(root->getright(), "right", level + 1);
    }
}
template<class T>
void BSTree<T>::print(Node<T>* root)
{
    if (root == NULL)
    {
        cout << "BST is empty\n" << endl;
        return;
    }
    const char* dir = "root";
    int level = 0;
    printBST(root, dir, level);
    cout << endl;
}
template<class T>
void BSTree<T>::isEmpty(Node<T>* root)
{
    if (root == NULL)
    {
        cout << "BST is empty\n" << endl;
        return;
    }
    cout << "BST isn't empty\n" << endl;
}
template<class T>
void BSTree<T>::clear(Node<T>** root)
{
    *root = NULL;
    cout << "BST was cleared\n" << endl;
}