﻿#include "BSTree.h"

int main() 
{
    BSTree<int> B;
    Node<int>* root = NULL;
    B.isEmpty(root);
    B.insert(&root, 7);
    B.insert(&root, 12);
    B.insert(&root, 8);
    B.insert(&root, 9);
    B.insert(&root, 10);
    B.insert(&root, 3);
    B.insert(&root, 4);
    B.print(root);
    B.isEmpty(root);
    B.isContains(root, 4);
    B.isContains(root, 5);
    B.del(root, 4);
    B.print(root);
    B.del(root, 8);
    B.print(root);
    B.del(root, 7);
    B.print(root);
    B.clear(&root);
    B.print(root);
    B.insert(&root, 1);
    B.insert(&root, 4);
    B.insert(&root, 8);
    B.insert(&root, 2);
    B.insert(&root, 3);
    B.print(root);
}
