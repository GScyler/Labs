#pragma once
#include <iostream>
using namespace std;

template<class T>
class Node
{
private:
	T data;
	Node<T>* left;
	Node<T>* right;
	Node<T>* parent;
public:
	Node();
	Node(T data, Node<T>* left, Node<T>* right, Node<T>* parent);
	Node(Node<T>& n);
	~Node();
	const T getdata() const;
	void setdata(const T data);
	Node<T>* getleft() const;
	void setleft(Node<T>* left);
	Node<T>* getright() const;
	void setright(Node<T>* right);
	Node<T>* getparent() const;
	void setparent(Node<T>* parent);
};
template<class T>
Node<T>::Node()
{
	data = NULL;
	left = NULL;
	right = NULL;
	parent = NULL;
}
template<class T>
Node<T>::Node(T data, Node<T>* left, Node<T>* right, Node<T>* parent)
{
	this->data = data;
	this->left = left;
	this->right = right;
	this->parent = parent;
}
template<class T>
Node<T>::Node(Node<T>& n)
{
	data = n.data;
	left = n.left;
	right = n.right;
	parent = n.parent;
}
template<class T>
Node<T>::~Node()
{
	data = NULL;
	left = NULL;
	right = NULL;
	parent = NULL;
}
template<class T>
const T Node<T>::getdata() const { return data; }
template<class T>
void Node<T>::setdata(const T data) { this->data = data; }
template<class T>
Node<T>* Node<T>::getleft() const { return left; }
template<class T>
void Node<T>::setleft(Node<T>* left) { this->left = left; }
template<class T>
Node<T>* Node<T>::getright() const { return right; }
template<class T>
void Node<T>::setright(Node<T>* right) { this->right = right; }
template<class T>
Node<T>* Node<T>::getparent() const { return parent; }
template<class T>
void Node<T>::setparent(Node<T>* parent) { this->parent = parent; }