#ifndef CITY_H_INCLUDED
#define CITY_H_INCLUDED
#include "GeographicObject.h"

class City :public GeographicObject
{
private:
    string country;
    int countResidents;
public:
    City();
    City(const string name, const string coordinates, const string country, const int countResidents);
    City(City &c);
    ~City();

	const string getcountry() const;
	void setcountry(const string country);
	const int getcountResidents() const;
	void setcountResidents(const int countResidents);

	const void print() const override;

	City & operator=(const City &ct);
};


#endif // CITY_H_INCLUDED
