#include "Country.h"

Country::Country()
{
	this->capital = "None";
}
Country::Country(const string name, const string coordinates, const string capital) : GeographicObject(name, coordinates)
{
	this->capital = capital;
}
Country::Country(Country &c) : GeographicObject(c.name,c.coordinates)
{
    this->capital = c.capital;
}
Country::~Country()
{
    cout << "Country ";
}
	const string Country::getcapital() const { return capital; }
	void Country::setcapital(const string capital) { this->capital = capital; }

const void Country::print() const
{
    cout << "Name: " << name << "\nCoordinates: " << coordinates << "\nCapital: " << capital << endl << endl;
}
Country & Country::operator=(const Country &ct)
{
    if(this == &ct)
        return *this;
    Country::name = ct.name;
    Country::coordinates = ct.coordinates;
    Country::capital = ct.capital;
    return *this;
}
