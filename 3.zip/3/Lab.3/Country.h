#ifndef COUNTRY_H_INCLUDED
#define COUNTRY_H_INCLUDED
#include "GeographicObject.h"

class Country :public GeographicObject
{
private:
    string capital;
public:
    Country();
    Country(const string name, const string coordinates, const string capital);
    Country(Country &c);
    ~Country();

	const string getcapital() const;
	void setcapital(const string capital);

	const void print() const override;

	Country & operator=(const Country &ct);
};


#endif // COUNTRY_H_INCLUDED
