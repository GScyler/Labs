#include "GeographicObject.h"

GeographicObject::GeographicObject()
{
	this->name = "None";
	this->coordinates = "None";
}
GeographicObject::GeographicObject(const string name, const string coordinates)
{
	this->name = name;
	this->coordinates = coordinates;
}
GeographicObject::GeographicObject(GeographicObject &g)
{
    this->name = g.name;
    this->coordinates = g.coordinates;
}
GeographicObject::~GeographicObject()
{
    cout << name << " on " << coordinates << " was destroyed.\n" << endl;
}
    const string GeographicObject::getname() const { return name; }
	void GeographicObject::setname(const string name) { this->name = name; }
	const string GeographicObject::getcoordinates() const { return coordinates; }
	void GeographicObject::setcoordinates(const string coordinates) { this->coordinates = coordinates; }
