#ifndef GEOGRAPHICOBJECT_H_INCLUDED
#define GEOGRAPHICOBJECT_H_INCLUDED
#include <iostream>
#include <string.h>
using namespace std;

class GeographicObject
{
protected:
    string name;
    string coordinates;
public:
	GeographicObject();
	GeographicObject(const string name, const string coordinates);
	GeographicObject(GeographicObject &g);
	~GeographicObject();

	const string getname() const;
	void setname(const string name);
	const string getcoordinates() const;
	void setcoordinates(const string coordinates);

	virtual const void print() const = 0;
};

#endif // GEOGRAPHICOBJECT_H_INCLUDED
