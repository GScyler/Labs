#include "City.h"

City::City()
{
	this->country = "None";
	this->countResidents = 0;
}
City::City(const string name, const string coordinates, const string country, const int countResidents) : GeographicObject(name, coordinates)
{
	this->country = country;
	this->countResidents = countResidents;
}
City::City(City &c) : GeographicObject(c.name,c.coordinates)
{
    this->country = c.country;
	this->countResidents = c.countResidents;
}
City::~City()
{
    cout << "City ";
}
	const string City::getcountry() const { return country; }
	void City::setcountry(const string country) { this->country = country; }
	const int City::getcountResidents() const { return countResidents; }
	void City::setcountResidents(const int countResidents) { this->countResidents = countResidents; }

const void City::print() const
{
    cout << "Name: " << name << "\nCoordinates: " << coordinates << "\nCountry: " << country << "\nPopulation: " << countResidents << endl << endl;
}
City & City::operator=(const City &ct)
{
    if(this == &ct)
        return *this;
    City::name = ct.name;
    City::coordinates = ct.coordinates;
    City::country = ct.country;
    City::countResidents = ct.countResidents;
    return *this;
}
