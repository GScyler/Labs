#include <iostream>
#include "Country.h"
#include "City.h"
#include "NaturalObject.h"

int main()
{
    Country Russia("Russia", "60, 100", "Moscow");
    Russia.print();

    Country USA = Russia;
    USA.setname("USA");
    USA.setcoordinates("38, 97");
    USA.setcapital("Washington");

    Country *Print = &USA;
    Print->print();

    City Moscow("","","Russia",282);
    Moscow.setname("Moscow");
    Moscow.setcoordinates(Russia.getcoordinates());

    City *Prnt = &Moscow;
    Prnt->print();

    NaturalObject Baikal("Baikal","54, 108");
    Baikal.print();

    return 0;
}
