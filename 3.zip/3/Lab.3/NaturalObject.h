#ifndef NATURALOBJECT_H_INCLUDED
#define NATURALOBJECT_H_INCLUDED
#include "GeographicObject.h"

class NaturalObject :public GeographicObject
{
public:

    NaturalObject(const string name, const string coordinates);
    NaturalObject(NaturalObject &n);
    ~NaturalObject();

	const void print() const override;

	NaturalObject & operator=(const NaturalObject &no);
};


#endif // NATURALOBJECT_H_INCLUDED
