#include "NaturalObject.h"

NaturalObject::NaturalObject(const string name, const string coordinates) : GeographicObject(name, coordinates){}
NaturalObject::NaturalObject(NaturalObject &n) : GeographicObject(n.name,n.coordinates){}
NaturalObject::~NaturalObject()
{
    cout << "Natural object ";
}

const void NaturalObject::print() const
{
    cout << "Name: " << name << "\nCoordinates: " << coordinates << endl << endl;
}
NaturalObject & NaturalObject::operator=(const NaturalObject &no)
{
    if(this == &no)
        return *this;
    NaturalObject::name = no.name;
    NaturalObject::coordinates = no.coordinates;
    return *this;
}
